let Czr = require("../src/index.js");
let czr = new Czr();
console.log(czr);
console.log(czr.__proto__);