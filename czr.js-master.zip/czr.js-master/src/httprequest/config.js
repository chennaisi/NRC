const options = {
    host: "127.0.0.1",
    port: 8765
};
module.exports = options;