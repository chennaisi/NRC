/* Export Client Class */
module.exports.Client = require('./json-rpc.js');